#include "TravelItinerary.h"
#include <iostream>
#include<string>
using namespace std;

void TravelItinerary::displayOptimizedItinerary()
{
    cout << "Optimized Itinerary:\n";
    // Display the optimized itinerary in the order they should be visited
    for (int i=0; i<destinations.size(); i++)
        {
        int currentDestinationIndex = i;
        cout << "Destination: " << destinations[currentDestinationIndex].name << endl;
        // Iterate through activities in the order they should be visited
        for (int j = 0; j < destinations[currentDestinationIndex].activities.size(); j++)
        {
            int currentActivityIndex = j;
            const auto& activity = destinations[currentDestinationIndex].activities[currentActivityIndex];
            cout << " - " << activity.name << " on " << activity.date;
            if (activity.completed)
            {
                cout << " (Completed)";
            }
            cout << " (Mode of Transportation: " << activity.modeOfTransportation << ")" << endl;
        }
        cout << endl;
    }
}

// Function to get user input for distances between destinations
void TravelItinerary::getUserInputForDistances(const vector<Destination>& destinations, vector<vector<pair<int, int>>>& adjacencyList)
{
    int n = destinations.size();
        cout << "Enter distances between destinations (enter -1 if not connected):\n";
        for (int i = 0; i < n; i++)
            {
            for (int j = i + 1; j < n; j++)
            {
                int distance;
                cout << "Distance from " << destinations[i].name << " to " << destinations[j].name << ": ";
                cin >> distance;
                // Assuming undirected graph, update both directions
                adjacencyList[i].push_back({j, distance});
                adjacencyList[j].push_back({i, distance});
            }
        }
}

void TravelItinerary::addDestination(const string& destinationName)
{
    Destination destination(destinationName);
    destinations.push_back(destination);
}

void TravelItinerary::addActivities(const string& destinationName, const string& activityNames, const string& date)
{
    for (int i = 0; i < destinations.size(); i++)
        {
        if (destinations[i].name == destinationName)
        {
            // Split the comma-separated activity names
            vector<string> activityList;
            int pos = 0;
            int startPos = 0;
            while ((pos = activityNames.find(',', startPos)) != string::npos)
                {
                string activityName = activityNames.substr(startPos, pos - startPos);
                startPos = pos + 1;
                activityList.push_back(activityName);
            }

            // Add the last activity
            string lastActivity = activityNames.substr(startPos);
            if (!lastActivity.empty())
                {
                activityList.push_back(lastActivity);
            }
            // Add activities to the destination
            destinations[i].addActivities(activityList, date);
            break;
        }
    }
}

void TravelItinerary::optimizeRoutes()
{
    // Get user input for distances between destinations
    vector<vector<pair<int, int>>> adjacencyList(destinations.size());
    getUserInputForDistances(destinations, adjacencyList);
    // Choose a starting point (for example, the first destination)
    int start = 0;
    // Initialize distance vector to store shortest paths
    vector<int> distance(destinations.size(), numeric_limits<int>::max());
    // Run Dijkstra's algorithm to compute shortest paths
    dijkstra(adjacencyList, distance, start);
    // Get the order of optimized routes
    vector<int> order(destinations.size());
    iota(order.begin(), order.end(), 0);
    sort(order.begin(), order.end(), [&distance](int a, int b)
         {
        return distance[a] < distance[b];
    });
    // Display the optimized itinerary
    displayOptimizedRoutes(order);
}

void TravelItinerary::dijkstra(const vector<vector<pair<int, int>>>& adjacencyList, vector<int>& distance, int start)
{
    int n = distance.size();
    vector<bool> visited(n, false);

    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pqueue;
    pqueue.push({0, start});
    distance[start] = 0;

    while (!pqueue.empty())
        {
        int u = pqueue.top().second;
        pqueue.pop();

        if (visited[u])
            {
            continue;
        }

        visited[u] = true;

        for (const auto& edge : adjacencyList[u])
            {
            int v = edge.first;
            int weight = edge.second;

            if (!visited[v] && distance[v] > distance[u] + weight)
                {
                distance[v] = distance[u] + weight;
                pqueue.push({distance[v], v});
            }
        }
    }
}


void TravelItinerary::displayItinerary()
{
    // Displaying the user's itinerary
    for (const auto& destination : destinations)
        {
        cout << "Destination: " << destination.name << endl;
        for (const auto& activity : destination.activities)
        {
            cout << " - " << activity.name << " on " << activity.date;
            if (activity.completed)
             {
                cout << " (Completed)";
            }
            cout << " (Mode of Transportation: " << activity.modeOfTransportation << ")" << endl;
        }
        cout << endl;
    }
}

void TravelItinerary::setPreferences()
{
    // Set mode of transportation for each activity
    for (auto& destination : destinations)
        {
        for (auto& activity : destination.activities)
        {
            cout << "Enter mode of transportation for " << activity.name << ": ";
            cin >> activity.modeOfTransportation;
        }
    }
}

void TravelItinerary::viewReminders()
{
    // Displaying upcoming reminders for incomplete activities
    cout << "Upcoming Reminders:\n";
    for (const auto& destination : destinations)
        {
        for (const auto& activity : destination.activities)
        {
            if (!activity.completed)
            {
                cout << "Reminder: " << activity.name << " on " << activity.date << " (Mode of Transportation: " << activity.modeOfTransportation << ")" << endl;
            }
        }
    }
}


void TravelItinerary::markActivityCompleted(const string& destinationName, const string& activityName)
{
    for (auto& destination : destinations)
        {
        if (destination.name == destinationName)
        {
            // Implement BFS to find the activity within the destination's activities
            queue<int> bfsQueue;
            vector<bool> visited(destination.activities.size(), false);

            for (int i = 0; i < destination.activities.size(); i++)
                {
                if (destination.activities[i].name == activityName)
                {
                    destination.activities[i].completed = true;
                    cout << "Marked activity as completed: " << activityName << " at destination " << destinationName << endl;
                    return;  // Exit the function once the activity is found and marked
                }
            }

            // If the activity is not found in the initial search, use BFS to find it
            for (int i = 0; i < destination.activities.size(); i++)
                {
                if (!visited[i]) {
                    bfsQueue.push(i);
                    visited[i] = true;

                    while (!bfsQueue.empty())
                        {
                        int currentActivityIndex = bfsQueue.front();
                        bfsQueue.pop();

                        if (destination.activities[currentActivityIndex].name == activityName)
                            {
                            // Mark the activity as completed
                            destination.activities[currentActivityIndex].completed = true;
                            cout << "Marked activity as completed: " << activityName << " at destination " << destinationName << endl;
                            return;  // Exit the function once the activity is found and marked
                        }

                        // Enqueue adjacent activities for further exploration
                        for (const auto& edge : adjacencyList[currentActivityIndex])
                            {
                            int adjacentActivityIndex = edge.first;
                            if (!visited[adjacentActivityIndex])
                            {
                                bfsQueue.push(adjacentActivityIndex);
                                visited[adjacentActivityIndex] = true;
                            }
                        }
                    }
                }
            }

            // If the activity is still not found, it does not exist
            cout << "Error: Activity not found - Destination: " << destinationName << ", Activity: " << activityName << endl;
            return;
        }
    }

    // If the destination is not found
    cout << "Error: Destination not found - Destination: " << destinationName << endl;
}


void TravelItinerary::displayOptimizedRoutes(const vector<int>& order)
{
    cout << "Optimized Itinerary:\n";

    // Display the optimized itinerary in the order they should be visited
    for (int i = 0; i < destinations.size(); i++) {
        int currentDestinationIndex = order[i];
        cout << "Destination: " << destinations[currentDestinationIndex].name << endl;
        // Iterate through activities in the order they should be visited
        for (int j = 0; j < destinations[currentDestinationIndex].activities.size(); j++) {
            int currentActivityIndex = j;
            const auto& activity = destinations[currentDestinationIndex].activities[currentActivityIndex];
            cout << " - " << activity.name << " on " << activity.date;
            if (activity.completed) {
                cout << " (Completed)";
            }
            cout << " (Mode of Transportation: " << activity.modeOfTransportation << ")" << endl;
        }
        cout << endl;
    }
}
