#include "Destination.h"
Destination::Destination(const string& n):name(n)
{

}

void Destination::addActivities(const vector<string>& activityNames, const string& date)
{
    for (const auto& activityName:activityNames)
        {
        Activity activity(activityName,date);
        activities.push_back(activity);
        }
}
