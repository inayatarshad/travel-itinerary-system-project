#include "Activity.h"
Activity::Activity(const string& n, const string& d):name(n),date(d),completed(false),modeOfTransportation("Not Mentioned")
{

}

void Activity::setModeOfTransportation(const string& mode)
{
    modeOfTransportation=mode;
}

