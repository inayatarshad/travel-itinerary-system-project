#include <iostream>
#include"Activity.h"
#include"Destination.h"
#include"TravelItinerary.h"
using namespace std;

int main()
{
    TravelItinerary planner;
    int choice;
    do {
        cout << "\n===== Travel Itinerary Planner =====\n"
             << "1. Add Destination\n"
             << "2. View Itinerary\n"
             << "3. Optimize Routes\n"
             << "4. Set Preferences\n"
             << "5. View Reminders\n"
             << "6. Mark Activity as Completed\n"
             << "7. Exit\n\n"
             << "Enter your choice: ";
        cin>>choice;
        switch(choice)
        {
            case 1:
                {
                cout<<"===== Add Destination =====\n";
                string destinationName;
                cout<<"Enter destination name: ";
                cin>>destinationName;
                planner.addDestination(destinationName);
                string activityNames,date;
                cout<<"Enter activities (comma-separated): ";
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                getline(cin, activityNames);
                cout<<"Enter preferred date (DD/MM/YYYY): ";
                cin>>date;
                planner.addActivities(destinationName, activityNames, date);
                break;
            }
            case 2:
                cout<<"===== View Itinerary =====\n";
                planner.displayItinerary();
                break;
            case 3:
                cout<<"===== Optimize Routes =====\n";
                planner.optimizeRoutes();
                break;
            case 4:
                cout<<"===== Set Preferences =====\n";
                planner.setPreferences();
                break;
            case 5:
                cout<<"===== View Reminders =====\n";
                planner.viewReminders();
                break;
            case 6:
                {
                cout<<"===== Mark Activity as Completed =====\n";
                string destinationName,activityName;
                cout<<"Enter destination name: ";
                cin>>destinationName;
                cout<<"Enter activity name: ";
                cin>>activityName;
                planner.markActivityCompleted(destinationName,activityName);
                break;
            }
            case 7:
                cout<<"Exiting Travel Itinerary Planner...\n";
                break;
            default:
                cout<<"Invalid choice. Please enter a valid option.\n";
        }

    }while(choice!=7);
    return 0;
}
