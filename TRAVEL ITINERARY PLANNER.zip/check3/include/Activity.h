#ifndef ACTIVITY_H
#define ACTIVITY_H

#include <string>
using namespace std;

class Activity
{
public:
    string name;
    string date;
    bool completed;
    string modeOfTransportation;
    Activity(const string& n, const string& d);
    // Function to set mode of transportation
    void setModeOfTransportation(const string& mode);
};

#endif // ACTIVITY_H
