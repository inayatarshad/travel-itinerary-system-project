#ifndef DESTINATION_H
#define DESTINATION_H

#include <string>
#include <vector>
#include "Activity.h"
using namespace std;

class Destination
{
public:
    string name;
    vector<Activity> activities;
    Destination(const string& n);
    void addActivities(const vector<string>& activityNames,const string& date);
};

#endif // DESTINATION_H
