#ifndef TRAVEL_ITINERARY_H
#define TRAVEL_ITINERARY_H

#include <vector>
#include <queue>
#include <limits>
#include <numeric>
#include <algorithm>
#include "Destination.h"
using namespace std;

class TravelItinerary
{
private:
    vector<Destination> destinations;
    vector<vector<pair<int,int>>> optimizedRoutes;  // Store optimized routes
    vector<vector<pair<int,int>>> adjacencyList;    // Adjacency list
    void dijkstra(const vector<vector<pair<int,int>>>& adjacencyList,vector<int>& distance,int start);

public:
    void displayOptimizedItinerary();
    void addDestination(const string& destinationName);
    void addActivities(const string& destinationName,const string& activityNames,const string& date);
    void optimizeRoutes();
    void displayItinerary();
    void setPreferences();
    void viewReminders();
    void markActivityCompleted(const string& destinationName,const string& activityName);
    void displayOptimizedRoutes(const vector<int>& order);
    void getUserInputForDistances(const vector<Destination>& destinations,vector<vector<pair<int,int>>>& adjacencyList);
};

#endif // TRAVEL_ITINERARY_H
